
document.getElementById('admin-login-form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Admin login functionality will be integrated soon.');
});
